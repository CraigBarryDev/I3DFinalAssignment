#ifndef INPUT_H
#define INPUT_H

void handleInput();

#endif