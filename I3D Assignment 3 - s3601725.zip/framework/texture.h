#include "utils.h"

#ifndef TEXTURE_H
#define TEXTURE_H

typedef GLuint texture;
texture loadTexture(const char* filename);

#endif